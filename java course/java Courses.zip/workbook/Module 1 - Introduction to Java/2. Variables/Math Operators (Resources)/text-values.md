### Math Operators - Part 1
-----
```
Fred and George collected <result> sweets
There are <result> stars in the Milky Way and Andromeda galaxies.
With bonus marks, Ron scored <result>/10 on his potions test. Snape wasn't too thrilled



Fred has  <result>  more sweets than George
The Andromeda Galaxy has <result> more stars than the Milky Way
Snape ended up removing marks. Ron actually scored <result> on his potions test



Fred and George used a special spell to multiply their sweets to: <result>
Snape made an error on his excel, accidentally multiplying Ron's score to: <result>/10



Originally, Fred had  <result> times more sweets than George
Andromeda has <result> times more stars
Snape caught the error. Furious, he divided Ron's score to: <result>
```


### Math Operators - Part 2
-----

```  
10 is an even number, since dividing 10 by 2 has a remainder of: <remainder>
5 is an odd number, since dividing 5 by 2 has a remainder of: <remainder>
```

