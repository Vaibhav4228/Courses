public class Receipt {
    public static void main(String[] args) {


        System.out.println("Here's your receipt:\n");
        
        // See instructions on Learn the Part (Workbook 6.8)
        
        System.out.println("\t<apple i >: $<price i >"); // to be used in for loop.
    }
}
