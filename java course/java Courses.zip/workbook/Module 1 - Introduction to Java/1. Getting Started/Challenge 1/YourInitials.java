public class YourInitials {
    public static void main(String[] args) {
         // Instructions for this workbook are on Learn the Part (See the Udemy Video: Your Initials to access the link).

            System.out.println(" SSS     A  ");
            System.out.println("S   S   A A ");
            System.out.println("S      A   A");
            System.out.println(" SSS   AAAAA");
            System.out.println("    S  A   A");
            System.out.println("S   S  A   A");
            System.out.println(" SSS   A   A");
    }
}
