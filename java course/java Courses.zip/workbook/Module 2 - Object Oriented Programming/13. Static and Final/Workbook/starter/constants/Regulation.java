package constants;

public class Regulation {

    // constants go here


}


