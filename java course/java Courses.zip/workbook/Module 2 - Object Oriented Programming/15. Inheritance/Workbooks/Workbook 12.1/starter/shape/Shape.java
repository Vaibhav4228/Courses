package shape;

public class Shape {    

}