package model;

public class Car {

}