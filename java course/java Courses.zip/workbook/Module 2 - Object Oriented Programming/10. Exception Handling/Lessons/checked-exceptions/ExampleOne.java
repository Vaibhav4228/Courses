public class ExampleOne {
    public static void main(String[] args) {

    }
    
}