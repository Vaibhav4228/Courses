public class Grades {
   public static void main(String[] args) {
       char positions = 'A';
       char arithmancy = 'B';
       char charms = 'C';

       System.out.println();
       
   } 
}
