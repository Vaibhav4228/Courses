public class bus {
public static void main(String[] args) {
    int mySecondNumber = 0;
    mySecondNumber= mySecondNumber+9;

    System.out.println(mySecondNumber);
}
}
