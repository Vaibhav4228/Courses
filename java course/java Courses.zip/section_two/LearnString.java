public class LearnString {
    public static void main(String[] args) {
    int year = 2021;
    String winner = "india";
        String result = "the winner of the world cup " + year + " is " + winner;
      System.out.println(result);
    
    } 
}
